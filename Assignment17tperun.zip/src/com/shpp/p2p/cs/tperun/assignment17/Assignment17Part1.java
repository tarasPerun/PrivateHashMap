package com.shpp.p2p.cs.tperun.assignment17;

/* this class runs tests of the user's own collections. */

import com.shpp.p2p.cs.tperun.assignment17.Tests.*;

public class Assignment17Part1 {

    public static void main(String[] args) {

        TestHashMap.performTests();
        TestPriorityQueue.performTests();

        /* Remove slashes if you want to test these collections */
        //  TestArrayList.performTests();
        //  TestLinkedList.performTests();
        //  TestStack.performTests();
        //  TestQueue.performTests();
    }
}
